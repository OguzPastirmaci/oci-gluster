#!/bin/bash
set -x


gluster_probe_peers()
{
  echo GLUSTER PROBING PEERS
  sleep 60
  host=`hostname -i`
  for i in `seq 2 $server_node_count`;
  do
    gluster peer probe ${server_filesystem_vnic_hostname_prefix}${i}.${filesystem_subnet_domain_name} --mode=script
  done
  sleep 20
  gluster peer status
}



create_gluster_volumes()
{
  # Gather list of block devices for brick config
  brick_lst=$(ls /bricks | sort)
  brick_cnt=$(ls /bricks | sort | wc -l)
  count=1
  buffer=""
  for brick in $brick_lst
  do
    for i in `seq 1 $server_node_count`;
    do
      buffer="$buffer ${server_filesystem_vnic_hostname_prefix}${i}:/bricks/${brick}/brick "
    done

    count=$((count+1))
  done

  if [ "$volume_types" = "Distributed" ]; then
    command_parameters=" transport tcp $buffer  force --mode=script"
  elif [ "$volume_types" = "DistributedReplicated" -o  "$volume_types" = "Replicated" ]; then
    command_parameters=" replica $replica transport tcp $buffer  force --mode=script"
  elif [ "$volume_types" = "DistributedDispersed" -o  "$volume_types" = "Dispersed" ]; then
    command_parameters=" disperse $server_node_count redundancy 1 transport tcp $buffer  force --mode=script"
  else
    echo "Invalid volume type input, exiting...."
    exit 1;
  fi

  gluster volume create glustervol $command_parameters
  sleep 20
  gluster volume set glustervol ctime off
  gluster volume start glustervol force --mode=script
  sleep 20
  gluster volume status --mode=script
  gluster volume info --mode=script
}


# Start of the script
server_node_count=$1
server_filesystem_vnic_hostname_prefix=$2
filesystem_subnet_domain_name=$3
volume_types=$4
replica=$5
gluster_probe_peers
create_gluster_volumes

exit 0;

